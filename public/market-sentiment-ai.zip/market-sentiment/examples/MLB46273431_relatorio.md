# Relatório de Sentimento — JBL Boombox 3 Bluetooth Squad

- **URL:** https://www.mercadolivre.com.br/jbl-boombox-3/p/MLB46273431
- **Preço:** 2.699
- **Avaliação média (site):** 4.8 (1200 avaliações)
- **Gerado em:** 2026-06-26T22:34:05.889829+00:00

## Volume coletado
- Comentários coletados: **12**
- Com texto: **10**
- Com estrelas: **12**

## Distribuição de estrelas
Média das estrelas coletadas: **4.0**

| Estrelas | Qtd |
|---|---|
| 5★ | 7 |
| 4★ | 2 |
| 3★ | 0 |
| 2★ | 2 |
| 1★ | 1 |

## Sentimento
Score médio: **0.399** (-1 negativo … +1 positivo)

- positivo ██████████████████······  75.0%  (9)
- neutro   ························   0.0%  (0)
- negativo ██████··················  25.0%  (3)

## Principais termos
- **Em avaliações positivas:** comentarios (1), simplesmente (1), linha (1), maravilhosa (1), alto (1), nivel (1), duvida (1), potente (1), excelente (1), qualidade (1), recomendo (1), demais (1)
- **Em avaliações negativas:** defeito (1), pessimo (1), tive (1), devolver (1), achei (1), caro (1), pelo (1), entrega (1), fraco (1), esquentando (1), problema (1), serio (1)

## Características do produto

Marca: JBL | Modelo: Boombox 3 | Conexão: Bluetooth | Potência: 180 W | À prova d'água: Sim (IP67)
