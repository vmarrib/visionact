from market_sentiment.sentiment import analisar_texto
from market_sentiment.sentiment.analyzer import criar_analisador


def test_positivo():
    rot, score = analisar_texto("Produto excelente, maravilhoso, recomendo!")
    assert rot == "positivo" and score > 0


def test_negativo():
    rot, score = analisar_texto("Péssimo, veio quebrado e parou de funcionar.")
    assert rot == "negativo" and score < 0


def test_negacao():
    rot, _ = analisar_texto("não recomendo, produto ruim")
    assert rot == "negativo"


def test_neutro():
    rot, _ = analisar_texto("chegou na data prevista")
    assert rot == "neutro"


def test_backend_lexicon_callable():
    f = criar_analisador("lexicon")
    assert callable(f)
