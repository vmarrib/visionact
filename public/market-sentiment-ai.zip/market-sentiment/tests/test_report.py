from market_sentiment.models import Produto, Review
from market_sentiment.sentiment import analisar_reviews
from market_sentiment.report import gerar_relatorio


def _produto():
    p = Produto(url="http://x/p/MLB1", nome="JBL Boombox", produto_id="MLB1")
    p.reviews = [
        Review(texto="Bom.", estrelas=5, util=13),
        Review(texto="Sem comentários e simplesmente top de linha maravilhosa, jbl alto nivel.", estrelas=5, util=11),
        Review(texto="Sem dúvida mt top.", estrelas=5, util=6),
        Review(texto="Veio com defeito, péssimo, devolvi.", estrelas=1),
        Review(texto="", estrelas=4),
    ]
    return p


def test_relatorio_totais():
    p = _produto()
    analisar_reviews(p.reviews)
    rel = gerar_relatorio(p)
    assert rel["totais"]["comentarios_coletados"] == 5
    assert rel["estrelas"]["distribuicao"]["5"] == 3
    assert rel["sentimento"]["distribuicao"].get("positivo", 0) >= 3
    assert rel["sentimento"]["distribuicao"].get("negativo", 0) >= 1
