# Arquitetura

## Visão geral
Pipeline linear, cada estágio com contrato de dados explícito (`market_sentiment/models.py`):

`URL → Produto(reviews[]) → Produto com sentimento → Relatório (dict/JSON/MD/CSV)`

## Estágios

### 1. Scraping (`scraper/`)
- `mercadolivre.py`: abre a página, fecha modais, extrai nome/preço/características, abre "Mostrar todas as opiniões" e pagina/rola até esgotar.
- `popups.py`: camada de robustez contra modais (Meli+, cookies, login).
- Estrelas: lidas por `aria-label`, fallback contando ícones preenchidos.

### 2. Sentimento (`sentiment/`)
- `lexicon.py`: dicionário PT-BR ponderado (-3..3) + negadores + intensificadores.
- `analyzer.py`: normaliza texto (sem acento), calcula score [-1,1], mapeia em rótulo por limiares. Backend transformer plugável via `pipeline` do HuggingFace.

### 3. Relatório (`report/`)
- `builder.py`: agrega totais, distribuição de estrelas, distribuição/percentual de sentimento, score médio e extração de termos frequentes (com stopwords PT). Exporta JSON, Markdown e CSV.

## Decisões de engenharia
- **Navegador real** para vencer renderização JS e bloqueio anti-bot.
- **Deduplicação** de comentários por prefixo do texto.
- **Backend de sentimento plugável**: baseline reprodutível por padrão, transformer quando há GPU/cobertura semântica necessária.
- **Contratos de dados (dataclasses)** desacoplam scraping, modelo e relatório — fácil adicionar novos marketplaces.
