# Guia de uso rápido

## 1. Instalar
```bash
pip install -r requirements.txt
playwright install chromium
```

## 2. Analisar um produto
```bash
python -m market_sentiment "https://www.mercadolivre.com.br/.../p/MLB46273431"
```

## 3. Ler o relatório
- `saida/MLB46273431_relatorio.md` — resumo.
- `saida/MLB46273431_relatorio.json` — métricas completas.
- `saida/MLB46273431_reviews.csv` — opiniões linha a linha.

## 4. Subir como serviço
```bash
uvicorn market_sentiment.api:app --reload
```

## Importar no GitHub
```bash
git init
git add .
git commit -m "Market Sentiment: scraping + sentimento + relatório"
git branch -M main
git remote add origin git@github.com:SEU_USUARIO/market-sentiment.git
git push -u origin main
```
