# Market Sentiment Intelligence

Cole o **link de um produto** e o sistema:

1. **Varre todas as opiniões** (comentários + estrelas) e as **características** do produto via web scraping com navegador real (Playwright).
2. Roda um **modelo de análise de sentimento** em cada comentário (positivo / neutro / negativo).
3. Gera um **relatório quantitativo**: quantos comentários, distribuição de estrelas, % de sentimento, score médio e principais termos de elogio/reclamação.

> Validado com Mercado Livre (ex.: JBL Boombox 3). A arquitetura de scraping é isolável por marketplace.

---

## Por que Playwright (e não requests/BeautifulSoup)?

O Mercado Livre renderiza opiniões, estrelas e características via JavaScript e bloqueia tráfego de datacenter quando detecta `requests`. Um navegador real executa o JS, mantém sessão/cookies e fecha os modais (Meli+, cookies, login) — exatamente como um usuário.

## Instalação

```bash
pip install -r requirements.txt
playwright install chromium
```

## Uso — CLI (cola o link)

```bash
python -m market_sentiment "https://www.mercadolivre.com.br/.../p/MLB46273431"
```

Saída no terminal + arquivos em `saida/`:
- `*_relatorio.json` — todas as métricas;
- `*_relatorio.md` — resumo legível;
- `*_reviews.csv` — uma linha por opinião (estrelas, sentimento, score, útil, texto).

Backend de sentimento:
```bash
# baseline em PT-BR, sem download (padrão)
python -m market_sentiment "<url>" --backend lexicon
# modelo transformer multilíngue (requer extra: pip install .[transformer])
python -m market_sentiment "<url>" --backend transformer
```

## Uso — API

```bash
uvicorn market_sentiment.api:app --reload
curl -X POST localhost:8000/analisar -H "Content-Type: application/json" \
  -d '{"url":"https://www.mercadolivre.com.br/.../p/MLB46273431"}'
```

## Docker

```bash
docker build -t market-sentiment .
docker run -p 8000:8000 market-sentiment
```

## Arquitetura

```text
  link do produto
        │
        ▼
  scraper/ (Playwright)         características + TODAS as opiniões + estrelas
        │
        ▼
  sentiment/ (lexicon|transformer)   rótulo + score por comentário
        │
        ▼
  report/                       relatório quantitativo (JSON · Markdown · CSV)
```

| Módulo | Responsabilidade |
|---|---|
| `market_sentiment/scraper` | Coleta produto, características, opiniões e estrelas |
| `market_sentiment/sentiment` | Modelo de sentimento (léxico PT-BR ou transformer) |
| `market_sentiment/report` | Métricas quantitativas e exportações |
| `market_sentiment/cli.py` | Ponto de entrada (cola o link) |
| `market_sentiment/api.py` | API FastAPI `POST /analisar` |

## Modelo de sentimento

- **lexicon (padrão):** baseline transparente e auditável em PT-BR, com tratamento de **negação** ("não recomendo") e **intensificadores** ("muito bom"). Sem download, ideal para reprodutibilidade.
- **transformer (opcional):** modelo HuggingFace multilíngue para maior cobertura semântica (ironia, contexto). Configurável via `MS_TRANSFORMER_MODEL`.

Quando o comentário não tem texto mas tem estrelas, as estrelas servem de sinal (5/4 → positivo, 3 → neutro, 1/2 → negativo).

## Configuração (variáveis de ambiente)

| Variável | Padrão | Descrição |
|---|---|---|
| `MS_HEADLESS` | `true` | Navegador sem interface |
| `MS_MAX_PAGINAS` | `60` | Limite de paginação de opiniões |
| `MS_SENTIMENT_BACKEND` | `lexicon` | `lexicon` ou `transformer` |
| `MS_LIMIAR_POS` / `MS_LIMIAR_NEG` | `0.15` / `-0.15` | Limiares de rótulo |
| `MS_DIR_SAIDA` | `saida` | Pasta de saída |

## Testes

```bash
pip install -r requirements-dev.txt
pytest -q
```

## Exemplo de saída

Veja [`examples/`](examples/) com um relatório real gerado para a JBL Boombox 3.

## Aviso legal

Uso educacional/analítico. Respeite os Termos de Uso e o `robots.txt` de cada site e a LGPD ao tratar conteúdo de terceiros.

---
Autoria: **Vanessa M. Ribeiro** — Engenheira & Cientista de Dados.
