"""Estruturas de dados do pipeline (uma fonte de verdade para todo o projeto)."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Review:
    """Uma opinião individual coletada do produto."""
    texto: str
    estrelas: Optional[int] = None          # 1..5
    util: Optional[int] = None              # quantos acharam útil
    pais: Optional[str] = None
    data: Optional[str] = None
    # preenchidos pelo analisador de sentimento:
    sentimento: Optional[str] = None        # positivo | neutro | negativo
    score: Optional[float] = None           # -1.0 .. 1.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Produto:
    """Metadados do produto-alvo."""
    url: str
    nome: str = ""
    produto_id: str = ""
    preco: Optional[str] = None
    avaliacao_media: Optional[float] = None   # média de estrelas exibida no site
    total_avaliacoes: Optional[int] = None    # total exibido no site
    caracteristicas: str = ""                 # todas concatenadas em uma string
    reviews: list[Review] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["reviews"] = [r.to_dict() for r in self.reviews]
        return d
