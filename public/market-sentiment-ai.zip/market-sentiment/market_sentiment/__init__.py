"""Market Sentiment Intelligence — análise de sentimento de reviews de e-commerce.

Pipeline: link do produto -> scraping de opiniões/estrelas/características ->
modelo de análise de sentimento -> relatório quantitativo.
"""
__version__ = "1.0.0"
