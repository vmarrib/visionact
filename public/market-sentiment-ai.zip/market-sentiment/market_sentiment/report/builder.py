"""Relatório quantitativo a partir do produto + reviews analisados.

Saídas:
  - dict (JSON-serializável) com todas as métricas;
  - resumo em Markdown legível;
  - CSV linha-a-linha das reviews.
"""
from __future__ import annotations

import csv
import io
import json
import re
import unicodedata
from collections import Counter
from datetime import datetime, timezone

from ..models import Produto

_STOPWORDS = {
    "a", "o", "e", "de", "da", "do", "que", "com", "para", "um", "uma", "os",
    "as", "no", "na", "em", "por", "se", "muito", "mais", "ja", "ja", "eu",
    "meu", "minha", "foi", "ele", "ela", "mas", "isso", "esta", "este", "ao",
    "dos", "das", "produto", "comprei", "chegou", "veio", "super", "bem", "ser",
    "tem", "sem", "pra", "ate", "tudo", "tao", "todo", "toda", "vou", "ter",
}


def _palavras(textos: list[str], n: int = 12) -> list[tuple[str, int]]:
    c: Counter[str] = Counter()
    for t in textos:
        norm = unicodedata.normalize("NFKD", (t or "").lower())
        norm = "".join(ch for ch in norm if not unicodedata.combining(ch))
        for w in re.findall(r"[a-z]{4,}", norm):
            if w not in _STOPWORDS:
                c[w] += 1
    return c.most_common(n)


def gerar_relatorio(produto: Produto) -> dict:
    reviews = produto.reviews
    total = len(reviews)
    com_texto = [r for r in reviews if (r.texto or "").strip()]

    estrelas = [r.estrelas for r in reviews if r.estrelas]
    dist_estrelas = {str(s): 0 for s in range(1, 6)}
    for s in estrelas:
        dist_estrelas[str(s)] = dist_estrelas.get(str(s), 0) + 1
    media_estrelas = round(sum(estrelas) / len(estrelas), 2) if estrelas else None

    dist_sent = Counter(r.sentimento for r in reviews if r.sentimento)
    n_sent = sum(dist_sent.values()) or 1
    pct_sent = {k: round(100 * v / n_sent, 1) for k, v in dist_sent.items()}

    scores = [r.score for r in reviews if r.score is not None]
    score_medio = round(sum(scores) / len(scores), 3) if scores else None

    positivas = [r.texto for r in reviews if r.sentimento == "positivo"]
    negativas = [r.texto for r in reviews if r.sentimento == "negativo"]

    return {
        "gerado_em": datetime.now(timezone.utc).isoformat(),
        "produto": {
            "nome": produto.nome,
            "url": produto.url,
            "produto_id": produto.produto_id,
            "preco": produto.preco,
            "avaliacao_media_site": produto.avaliacao_media,
            "total_avaliacoes_site": produto.total_avaliacoes,
            "caracteristicas": produto.caracteristicas,
        },
        "totais": {
            "comentarios_coletados": total,
            "comentarios_com_texto": len(com_texto),
            "comentarios_com_estrelas": len(estrelas),
        },
        "estrelas": {
            "media": media_estrelas,
            "distribuicao": dist_estrelas,
        },
        "sentimento": {
            "score_medio": score_medio,
            "distribuicao": dict(dist_sent),
            "percentual": pct_sent,
        },
        "temas": {
            "termos_em_positivas": _palavras(positivas),
            "termos_em_negativas": _palavras(negativas),
        },
    }


def _barra(pct: float, largura: int = 24) -> str:
    cheio = int(round(pct / 100 * largura))
    return "█" * cheio + "·" * (largura - cheio)


def relatorio_markdown(rel: dict) -> str:
    p = rel["produto"]
    t = rel["totais"]
    e = rel["estrelas"]
    s = rel["sentimento"]
    linhas = [
        f"# Relatório de Sentimento — {p['nome'] or 'Produto'}",
        "",
        f"- **URL:** {p['url']}",
        f"- **Preço:** {p['preco'] or 'n/d'}",
        f"- **Avaliação média (site):** {p['avaliacao_media_site'] or 'n/d'}"
        f" ({p['total_avaliacoes_site'] or 'n/d'} avaliações)",
        f"- **Gerado em:** {rel['gerado_em']}",
        "",
        "## Volume coletado",
        f"- Comentários coletados: **{t['comentarios_coletados']}**",
        f"- Com texto: **{t['comentarios_com_texto']}**",
        f"- Com estrelas: **{t['comentarios_com_estrelas']}**",
        "",
        "## Distribuição de estrelas",
        f"Média das estrelas coletadas: **{e['media']}**",
        "",
        "| Estrelas | Qtd |",
        "|---|---|",
    ]
    for k in ["5", "4", "3", "2", "1"]:
        linhas.append(f"| {k}★ | {e['distribuicao'].get(k, 0)} |")
    linhas += ["", "## Sentimento"]
    linhas.append(f"Score médio: **{s['score_medio']}** (-1 negativo … +1 positivo)")
    linhas.append("")
    for rotulo in ["positivo", "neutro", "negativo"]:
        pct = s["percentual"].get(rotulo, 0.0)
        qtd = s["distribuicao"].get(rotulo, 0)
        linhas.append(f"- {rotulo:8s} {_barra(pct)} {pct:5.1f}%  ({qtd})")
    linhas += ["", "## Principais termos"]
    pos = ", ".join(f"{w} ({n})" for w, n in rel["temas"]["termos_em_positivas"]) or "—"
    neg = ", ".join(f"{w} ({n})" for w, n in rel["temas"]["termos_em_negativas"]) or "—"
    linhas.append(f"- **Em avaliações positivas:** {pos}")
    linhas.append(f"- **Em avaliações negativas:** {neg}")
    if p["caracteristicas"]:
        linhas += ["", "## Características do produto", "", p["caracteristicas"]]
    return "\n".join(linhas) + "\n"


def reviews_csv(produto: Produto) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["estrelas", "sentimento", "score", "util", "comentario"])
    for r in produto.reviews:
        w.writerow([r.estrelas or "", r.sentimento or "", r.score if r.score is not None else "",
                    r.util or "", (r.texto or "").replace("\n", " ")])
    return buf.getvalue()


def salvar_relatorio(produto: Produto, rel: dict, dir_saida: str) -> dict[str, str]:
    import os
    os.makedirs(dir_saida, exist_ok=True)
    base = produto.produto_id or "produto"
    paths = {
        "json": os.path.join(dir_saida, f"{base}_relatorio.json"),
        "markdown": os.path.join(dir_saida, f"{base}_relatorio.md"),
        "csv": os.path.join(dir_saida, f"{base}_reviews.csv"),
    }
    with open(paths["json"], "w", encoding="utf-8") as f:
        json.dump(rel, f, ensure_ascii=False, indent=2)
    with open(paths["markdown"], "w", encoding="utf-8") as f:
        f.write(relatorio_markdown(rel))
    with open(paths["csv"], "w", encoding="utf-8") as f:
        f.write(reviews_csv(produto))
    return paths
