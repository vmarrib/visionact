"""Léxico de sentimento em português (PT-BR) focado em reviews de e-commerce.

Pesos em [-3, 3]. Compacto, mas cobre o vocabulário típico de avaliações de
produto (qualidade, entrega, custo-benefício, defeitos). Serve como baseline
transparente e auditável, sem depender de download de modelos.
"""
from __future__ import annotations

POSITIVO = {
    "otimo": 3, "ótimo": 3, "excelente": 3, "perfeito": 3, "maravilhoso": 3,
    "maravilhosa": 3, "incrivel": 3, "incrível": 3, "sensacional": 3, "top": 2,
    "amei": 3, "adorei": 3, "amo": 2, "recomendo": 2, "recomendado": 2,
    "satisfeito": 2, "satisfeita": 2, "bom": 2, "boa": 2, "bonito": 1,
    "lindo": 2, "linda": 2, "rapido": 1, "rápido": 1, "rapida": 1,
    "qualidade": 1, "duravel": 1, "durável": 1, "vale": 1, "valeu": 2,
    "funciona": 1, "potente": 2, "confortavel": 1, "confortável": 1,
    "barato": 1, "economico": 1, "econômico": 1, "eficiente": 2, "show": 2,
    "supera": 2, "superou": 2, "fantastico": 3, "fantástico": 3, "gostei": 2,
    "cumpre": 1, "atende": 1, "robusto": 1, "premium": 1, "impecavel": 3,
    "impecável": 3, "surpreendeu": 2, "feliz": 1, "agil": 1, "ágil": 1,
}

NEGATIVO = {
    "pessimo": -3, "péssimo": -3, "horrivel": -3, "horrível": -3, "ruim": -2,
    "terrivel": -3, "terrível": -3, "defeito": -2, "defeituoso": -2,
    "quebrou": -2, "quebrado": -2, "estragou": -2, "estragado": -2,
    "lixo": -3, "decepcao": -3, "decepção": -3, "decepcionado": -3,
    "decepcionada": -3, "decepcionante": -3, "fraco": -2, "fraca": -2,
    "lento": -2, "lenta": -2, "demora": -2, "demorou": -2, "atraso": -2,
    "atrasado": -2, "caro": -1, "falso": -3, "fake": -3, "golpe": -3,
    "arrependimento": -3, "arrependido": -3, "arrependida": -3, "frustrado": -2,
    "problema": -2, "problemas": -2, "parou": -2, "nao": 0, "não": 0,
    "pifou": -2, "veio": 0, "errado": -2, "danificado": -2, "vazando": -2,
    "barulho": -1, "esquentando": -1, "trava": -2, "travando": -2,
    "devolvi": -2, "devolver": -2, "reembolso": -2, "evitem": -3, "pessima": -3,
    "péssima": -3, "porcaria": -3,
}

# negadores que invertem a polaridade da próxima palavra
NEGADORES = {"nao", "não", "nunca", "jamais", "nenhum", "nenhuma", "sem"}
# intensificadores que amplificam a próxima palavra
INTENSIFICADORES = {
    "muito": 1.5, "super": 1.6, "extremamente": 1.8, "bastante": 1.4,
    "demais": 1.5, "totalmente": 1.5, "mega": 1.5, "mt": 1.4, "mto": 1.4,
}
