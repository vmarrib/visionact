"""Análise de sentimento dos reviews.

Dois backends:
  - "lexicon"     : baseline transparente em PT-BR (padrão, sem download).
  - "transformer" : modelo HuggingFace multilíngue (opcional, requer `transformers`).

Ambos preenchem `review.sentimento` (positivo/neutro/negativo) e `review.score`
(-1..1). A escolha vem de config.SENTIMENT_BACKEND.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Callable

from .. import config
from ..models import Review
from .lexicon import POSITIVO, NEGATIVO, NEGADORES, INTENSIFICADORES


def _normalizar(texto: str) -> list[str]:
    t = unicodedata.normalize("NFKD", texto.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.findall(r"[a-zA-Z]+", t)


# léxicos normalizados (sem acento) para casar com tokens normalizados
def _sem_acento(d: dict) -> dict:
    out = {}
    for k, v in d.items():
        nk = "".join(c for c in unicodedata.normalize("NFKD", k.lower()) if not unicodedata.combining(c))
        out[nk] = v
    return out


_POS = _sem_acento(POSITIVO)
_NEG = _sem_acento(NEGATIVO)
_NEGADORES = {"".join(c for c in unicodedata.normalize("NFKD", w) if not unicodedata.combining(c)) for w in NEGADORES}
_INTENS = _sem_acento(INTENSIFICADORES)


def _rotular(score: float) -> str:
    if score >= config.LIMIAR_POSITIVO:
        return "positivo"
    if score <= config.LIMIAR_NEGATIVO:
        return "negativo"
    return "neutro"


def _score_lexicon(texto: str) -> float:
    tokens = _normalizar(texto)
    if not tokens:
        return 0.0
    total = 0.0
    hits = 0
    for i, tok in enumerate(tokens):
        peso = _POS.get(tok, 0) + _NEG.get(tok, 0)
        if peso == 0:
            continue
        # intensificador imediatamente anterior
        if i > 0 and tokens[i - 1] in _INTENS:
            peso *= _INTENS[tokens[i - 1]]
        # negador até 2 tokens antes inverte a polaridade
        janela = tokens[max(0, i - 2):i]
        if any(w in _NEGADORES for w in janela):
            peso = -peso
        total += peso
        hits += 1
    if hits == 0:
        return 0.0
    # normaliza para [-1, 1] de forma suave
    media = total / hits
    return max(-1.0, min(1.0, media / 3.0))


def _make_lexicon() -> Callable[[str], float]:
    return _score_lexicon


def _make_transformer() -> Callable[[str], float]:
    from transformers import pipeline  # import tardio: só quando solicitado

    pipe = pipeline("sentiment-analysis", model=config.TRANSFORMER_MODEL, truncation=True)

    def _score(texto: str) -> float:
        if not texto.strip():
            return 0.0
        r = pipe(texto[:512])[0]
        label = r["label"].lower()
        conf = float(r.get("score", 0.5))
        if "pos" in label or label in {"5 stars", "4 stars"}:
            return conf
        if "neg" in label or label in {"1 star", "2 stars"}:
            return -conf
        return 0.0

    return _score


def criar_analisador(backend: str | None = None) -> Callable[[str], float]:
    """Devolve uma função texto -> score [-1,1] conforme o backend escolhido."""
    backend = backend or config.SENTIMENT_BACKEND
    if backend == "transformer":
        return _make_transformer()
    return _make_lexicon()


def analisar_texto(texto: str, scorer: Callable[[str], float] | None = None) -> tuple[str, float]:
    scorer = scorer or criar_analisador()
    score = scorer(texto)
    return _rotular(score), round(score, 4)


def analisar_reviews(reviews: list[Review], backend: str | None = None) -> list[Review]:
    """Aplica o modelo de sentimento em cada review (modifica e devolve a lista).

    Se a review tem estrelas mas o texto é vazio/curto, usa as estrelas como
    sinal de apoio para o rótulo (5/4=positivo, 3=neutro, 1/2=negativo).
    """
    scorer = criar_analisador(backend)
    for rv in reviews:
        rotulo, score = analisar_texto(rv.texto or "", scorer)
        if (not (rv.texto or "").strip() or abs(score) < 1e-9) and rv.estrelas:
            if rv.estrelas >= 4:
                rotulo, score = "positivo", 0.6
            elif rv.estrelas == 3:
                rotulo, score = "neutro", 0.0
            else:
                rotulo, score = "negativo", -0.6
        rv.sentimento = rotulo
        rv.score = score
    return reviews
