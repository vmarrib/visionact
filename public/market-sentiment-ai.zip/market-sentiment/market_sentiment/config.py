"""Configuração central do Market Sentiment (sobrescrevível por variáveis de ambiente)."""
import os

# ---- Scraping -------------------------------------------------------------
HEADLESS = os.getenv("MS_HEADLESS", "true").lower() == "true"
TIMEOUT_MS = int(os.getenv("MS_TIMEOUT_MS", "30000"))
MAX_PAGINAS_REVIEWS = int(os.getenv("MS_MAX_PAGINAS", "60"))
USER_AGENT = os.getenv(
    "MS_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
)

# ---- Sentimento -----------------------------------------------------------
# backend: "lexicon" (padrão, sem download) ou "transformer" (HuggingFace)
SENTIMENT_BACKEND = os.getenv("MS_SENTIMENT_BACKEND", "lexicon")
TRANSFORMER_MODEL = os.getenv(
    "MS_TRANSFORMER_MODEL",
    "lxyuan/distilbert-base-multilingual-cased-sentiments-student",
)
# limiares para mapear o score [-1,1] em rótulos
LIMIAR_POSITIVO = float(os.getenv("MS_LIMIAR_POS", "0.15"))
LIMIAR_NEGATIVO = float(os.getenv("MS_LIMIAR_NEG", "-0.15"))

# ---- Saída ----------------------------------------------------------------
DIR_SAIDA = os.getenv("MS_DIR_SAIDA", "saida")
