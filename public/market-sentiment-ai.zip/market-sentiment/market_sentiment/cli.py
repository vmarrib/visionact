"""CLI do Market Sentiment.

Uso:
    python -m market_sentiment <URL-do-produto> [--backend lexicon|transformer]

Fluxo: cola o link -> scraping de todas as opiniões/estrelas -> análise de
sentimento -> relatório quantitativo (JSON + Markdown + CSV) na pasta de saída.
"""
from __future__ import annotations

import argparse
import asyncio
import sys

from . import config
from .scraper import coletar_produto
from .sentiment import analisar_reviews
from .report import gerar_relatorio, salvar_relatorio
from .report.builder import relatorio_markdown


async def _run(url: str, backend: str, dir_saida: str) -> int:
    print(f"🔎 Coletando opiniões de: {url}")
    produto = await coletar_produto(url)
    print(f"   Produto: {produto.nome or '(sem título)'}")
    print(f"   Reviews coletadas: {len(produto.reviews)} "
          f"| características: {len(produto.caracteristicas)} chars")

    print(f"🧠 Rodando análise de sentimento (backend: {backend}) ...")
    analisar_reviews(produto.reviews, backend=backend)

    rel = gerar_relatorio(produto)
    paths = salvar_relatorio(produto, rel, dir_saida)

    print("\n" + relatorio_markdown(rel))
    print("💾 Arquivos gerados:")
    for k, v in paths.items():
        print(f"   - {k}: {v}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Market Sentiment — análise de reviews de produto.")
    parser.add_argument("url", help="Link do produto (ex.: Mercado Livre).")
    parser.add_argument("--backend", choices=["lexicon", "transformer"],
                        default=config.SENTIMENT_BACKEND, help="Modelo de sentimento.")
    parser.add_argument("--saida", default=config.DIR_SAIDA, help="Pasta de saída.")
    args = parser.parse_args(argv)
    try:
        return asyncio.run(_run(args.url, args.backend, args.saida))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
