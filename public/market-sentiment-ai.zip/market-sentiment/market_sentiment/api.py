"""API FastAPI opcional: POST /analisar com {"url": "..."} devolve o relatório JSON.

Subir com:  uvicorn market_sentiment.api:app --reload
"""
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from . import config
from .scraper import coletar_produto
from .sentiment import analisar_reviews
from .report import gerar_relatorio

app = FastAPI(title="Market Sentiment API", version="1.0.0")


class AnaliseRequest(BaseModel):
    url: str
    backend: str = config.SENTIMENT_BACKEND


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/analisar")
async def analisar(req: AnaliseRequest) -> dict:
    if "http" not in req.url:
        raise HTTPException(status_code=400, detail="URL inválida.")
    produto = await coletar_produto(req.url)
    analisar_reviews(produto.reviews, backend=req.backend)
    return gerar_relatorio(produto)
