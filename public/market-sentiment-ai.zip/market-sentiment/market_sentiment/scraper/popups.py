"""Fecha modais/janelas (Meli+, cookies, login, newsletter) que bloqueiam a coleta."""
from __future__ import annotations

SELETORES_FECHAR = [
    "button[data-testid='action:understood-button']",
    "button:has-text('Entendi')",
    "button:has-text('Em outro momento')",
    "a:has-text('Em outro momento')",
    "button.andes-modal__close",
    "button[aria-label='Fechar']",
    "button[aria-label='Close']",
    "button:has-text('Agora não')",
    "button:has-text('Depois')",
]


async def fechar_popups(page) -> None:
    for sel in SELETORES_FECHAR:
        try:
            loc = page.locator(sel).first
            if await loc.is_visible(timeout=600):
                await loc.click(timeout=1200)
                await page.wait_for_timeout(350)
        except Exception:
            pass
    try:
        await page.keyboard.press("Escape")
    except Exception:
        pass
