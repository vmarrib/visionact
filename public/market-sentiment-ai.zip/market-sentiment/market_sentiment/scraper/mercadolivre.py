"""Coletor de UM produto do Mercado Livre: características + TODAS as opiniões e estrelas.

Usa Playwright (navegador real) porque o ML renderiza opiniões via JavaScript e
bloqueia requests de datacenter. Cobre a página do produto e o modal completo de
opiniões ("Mostrar todas as opiniões").
"""
from __future__ import annotations

import re
from typing import Optional

from playwright.async_api import async_playwright, TimeoutError as PWTimeout

from .. import config
from ..models import Produto, Review
from .popups import fechar_popups


def _num(texto: str) -> Optional[int]:
    m = re.search(r"\d[\d.\s]*", texto.replace("\u00a0", " "))
    if not m:
        return None
    return int(re.sub(r"[^\d]", "", m.group(0)) or "0")


def _estrelas_de_texto(txt: str) -> Optional[int]:
    m = re.search(r"([1-5])\s*(de|/)\s*5", txt)
    if m:
        return int(m.group(1))
    m = re.search(r"Qualifica\w*\s*([1-5])", txt, re.I)
    return int(m.group(1)) if m else None


async def _caracteristicas(page) -> str:
    pares: dict[str, str] = {}
    try:
        itens = await page.locator(
            ".ui-pdp-highlighted-specs-res .ui-pdp-color--BLACK, "
            ".ui-vpp-highlighted-specs__attribute-columns p, "
            "[class*='highlighted-specs'] p"
        ).all_inner_texts()
        for t in itens:
            if ":" in t:
                k, v = t.split(":", 1)
                pares.setdefault(k.strip(), v.strip())
    except Exception:
        pass
    try:
        rows = await page.locator(
            ".andes-table__row, tr.andes-table__row, "
            ".ui-vpp-striped-specs__row, table tr"
        ).all()
        for r in rows:
            try:
                th = await r.locator("th, .andes-table__header, .ui-vpp-striped-specs__key").first.inner_text(timeout=500)
                td = await r.locator("td, .andes-table__column, .ui-vpp-striped-specs__value").first.inner_text(timeout=500)
                if th and td:
                    pares.setdefault(th.strip(), td.strip())
            except Exception:
                continue
    except Exception:
        pass
    return " | ".join(f"{k}: {v}" for k, v in pares.items() if k and v)


async def _media_e_total(page) -> tuple[Optional[float], Optional[int]]:
    media = total = None
    try:
        t = await page.locator(
            ".ui-pdp-review__rating, .ui-review-capability__rating__average, "
            "[class*='rating'][class*='average']"
        ).first.inner_text(timeout=2000)
        m = re.search(r"([0-5][.,]\d)", t)
        if m:
            media = float(m.group(1).replace(",", "."))
    except Exception:
        pass
    try:
        t = await page.locator(
            ".ui-pdp-review__amount, .ui-review-capability__rating__label, "
            "[class*='review'][class*='amount']"
        ).first.inner_text(timeout=2000)
        total = _num(t)
    except Exception:
        pass
    return media, total


async def _abrir_todas_opinioes(page) -> None:
    for sel in [
        "a:has-text('Mostrar todas as opiniões')",
        "button:has-text('Mostrar todas as opiniões')",
        "button:has-text('opiniões')",
        "a:has-text('opiniões')",
        "[data-testid='see-more']",
    ]:
        try:
            loc = page.locator(sel).first
            if await loc.is_visible(timeout=900):
                await loc.click(timeout=1500)
                await page.wait_for_timeout(1500)
                await fechar_popups(page)
                return
        except Exception:
            continue


async def _coletar_reviews(page) -> list[Review]:
    reviews: list[Review] = []
    vistos: set[str] = set()

    await _abrir_todas_opinioes(page)

    pagina = 0
    while pagina < config.MAX_PAGINAS_REVIEWS:
        pagina += 1
        artigos = await page.locator(
            "article.ui-review-capability-comments__comment, "
            ".ui-review-capability-comments__comment, "
            "[class*='review'][class*='comment'], "
            "article[class*='comment']"
        ).all()

        novos = 0
        for art in artigos:
            try:
                texto_bruto = (await art.inner_text(timeout=500)).strip()
            except Exception:
                continue
            corpo = re.sub(r"\s+", " ", texto_bruto)
            chave = corpo[:120]
            if not corpo or chave in vistos:
                continue
            vistos.add(chave)

            estrelas = None
            try:
                aria = await art.locator(
                    "[aria-label*='estrela'], [aria-label*='star'], [class*='rating']"
                ).first.get_attribute("aria-label", timeout=400)
                if aria:
                    estrelas = _estrelas_de_texto(aria)
            except Exception:
                pass
            if estrelas is None:
                try:
                    cheias = await art.locator(
                        "svg[class*='star'][class*='full'], "
                        "[class*='star--full'], [class*='filled']"
                    ).count()
                    if 1 <= cheias <= 5:
                        estrelas = cheias
                except Exception:
                    pass

            util = None
            try:
                t = await art.locator(":text('Útil')").first.inner_text(timeout=300)
                util = _num(t)
            except Exception:
                pass

            reviews.append(Review(texto=corpo, estrelas=estrelas, util=util))
            novos += 1

        avancou = False
        for sel in [
            "button.andes-pagination__button--next:not([disabled])",
            "a[title='Seguinte']",
            "button:has-text('Seguinte')",
            "li.andes-pagination__button--next a",
        ]:
            try:
                nxt = page.locator(sel).first
                if await nxt.is_visible(timeout=600):
                    await nxt.click(timeout=1500)
                    await page.wait_for_timeout(1400)
                    await fechar_popups(page)
                    avancou = True
                    break
            except Exception:
                continue

        if not avancou:
            await page.mouse.wheel(0, 4000)
            await page.wait_for_timeout(1100)
            if novos == 0:
                break
    return reviews


async def coletar_produto(url: str) -> Produto:
    """Coleta características + todas as opiniões/estrelas de um produto do Mercado Livre."""
    produto = Produto(url=url)
    m = re.search(r"(MLB-?\d+)", url)
    produto.produto_id = m.group(1).replace("-", "") if m else url

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=config.HEADLESS, args=["--no-sandbox"])
        ctx = await browser.new_context(
            user_agent=config.USER_AGENT, locale="pt-BR",
            viewport={"width": 1366, "height": 900},
        )
        page = await ctx.new_page()
        try:
            await page.goto(url, timeout=config.TIMEOUT_MS, wait_until="domcontentloaded")
            await fechar_popups(page)
            await page.wait_for_timeout(1200)

            try:
                produto.nome = (await page.locator("h1.ui-pdp-title, h1").first.inner_text(timeout=3000)).strip()
            except PWTimeout:
                produto.nome = ""
            try:
                produto.preco = (await page.locator(
                    ".andes-money-amount__fraction, .price-tag-fraction"
                ).first.inner_text(timeout=2000)).strip()
            except Exception:
                produto.preco = None

            produto.caracteristicas = await _caracteristicas(page)
            produto.avaliacao_media, produto.total_avaliacoes = await _media_e_total(page)
            produto.reviews = await _coletar_reviews(page)
        finally:
            await browser.close()
    return produto
