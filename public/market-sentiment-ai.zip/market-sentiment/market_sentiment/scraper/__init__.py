from .mercadolivre import coletar_produto
__all__ = ["coletar_produto"]
