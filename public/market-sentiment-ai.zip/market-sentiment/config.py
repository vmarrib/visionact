"""Atalho de compatibilidade: reexporta market_sentiment.config."""
from market_sentiment.config import *  # noqa: F401,F403
